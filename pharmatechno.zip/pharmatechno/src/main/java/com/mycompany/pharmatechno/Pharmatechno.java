package com.mycompany.pharmatechno;

import com.mycompany.pharmatechno.UI.main;

public class Pharmatechno {
    public static void main(String[] args) {
        main f = new main();
        f.setVisible(true);
    }
}
